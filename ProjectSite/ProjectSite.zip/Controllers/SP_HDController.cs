﻿using ProjectSite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ProjectSite.Controllers
{
    public class SP_HDController : ApiController
    {
        [HttpGet]
        [Route("api/SP_HD")]
        public List<SP_HD> GetAll()
        {
            List<SP_HD> planes = new SP_HDDAO().SelectAll();
            return planes;
        }


        [HttpGet]
        [Route("api/SP_HD/search/{keyword}")]
        public List<SP_HD> Search(String keyword)
        {
            List<SP_HD> planes = new SP_HDDAO().SelectByKeyword(keyword);
            return planes;
        }

        [HttpGet]
        [Route("api/SP_HD/{MAHD}")]
        public SP_HD GetDetails(int MAHD)
        {
            SP_HD plane = new SP_HDDAO().SelectById(MAHD);
            return plane;
        }


        [HttpPost]
        [Route("api/SP_HD")]
        public bool Addnew(SP_HD newPlane)
        {
            bool result = new SP_HDDAO().Insert(newPlane);
            return result;
        }

        [HttpDelete]
        [Route("api/SP_HD/{MAHD}")]
        public bool Delete(int MAHD)
        {
            bool result = new SP_HDDAO().Delete(MAHD);
            return result;

        }

        [HttpPut]
        [Route("api/SP_HD/{MAHD}")]
        public bool Update(int MAHD, SP_HD newPlane)
        {
            if (MAHD != newPlane.MAHD) return false;
            bool result = new SP_HDDAO().Update(newPlane);
            return result;
        }
    }
}